> 博客：<https://blog.hidove.cn/post/594>

## 描述

> 将苹果cms（maccms）的视频封面上传到图床

## 支持
* Hidove图床 Pro
* 兰空图床
* 其他Api接口

## 使用

> 解压覆盖即可

## 演示
![](https://blog.hidove.cn/usr/uploads/2019/11/389564838.png)

![](https://blog.hidove.cn/usr/uploads/2019/11/2770325897.png)

![](https://blog.hidove.cn/usr/uploads/2019/11/2718157264.png)
